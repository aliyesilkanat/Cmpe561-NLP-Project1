# Cmpe561NLP

<h2>Pos Tags:</h2>

Noun:N<br>
Verb:V<br>
Adjective:ADJ<br>
Adverb:ADV<br>
Auxillary Verb:AUX<br>
Proposition: PROP<br>
Pronoun: PRN

<h2>Other Tags:</h2>
Singular:SG<br>

<h2>Inflectional Suffix Tags</h2>
<h3>For Nouns:</h3>
Plural:PL
Singular Possesive: SGPS
Plural Possesive: PLPS

<h3>For Verbs:</h3>
Present 3rd Person Singular: 3D
Present Participle: ING
Past Tense: PT
Past Participle: PP
<h3>For Adjectives: </h3>
Comparative: CP
Superlative: SP
